# Bella Chat Android — perbaikan tampilan dan koneksi

Source Android Kotlin + Jetpack Compose.

## Perbaikan
- Tema Rose, Lavender, Peach, Mint, dan Midnight berada di menu Pengaturan.
- Tema aktif disimpan di SharedPreferences agar tetap terpilih setelah aplikasi dibuka kembali.
- Pesan pengguna tampil di kanan dan balasan Bella di kiri dalam gelembung chat yang lebih solid dan mudah dibaca.
- Wallpaper percakapan tetap terlihat dengan overlay tipis.
- Riwayat 9 pesan sebelumnya dikirim bersama pesan terbaru sebagai konteks percakapan.
- Riwayat Compose diambil pada main thread sebelum permintaan jaringan berjalan.
- Penanganan respons kosong, format JSON tidak sesuai, HTTP error, DNS, dan timeout dibuat lebih informatif.
- Endpoint AI: `https://bella-chat-ai.asupriadi488.workers.dev/chat`.

## Kontrak Cloudflare Worker
Aplikasi mengirim objek JSON dengan properti `history` (array role/content) dan `message` (teks terbaru).
Worker sebaiknya membalas JSON seperti `{"reply":"Hai, aku Bella!"}`. Aplikasi juga menerima properti teks `response`, `message`, `output`, atau `text`.

Jika Worker mengirim respons kosong atau tidak memiliki properti balasan, aplikasi menampilkan pesan diagnostik.

## Build APK melalui GitHub Actions
Workflow ada di `.github/workflows/android.yml`. Upload seluruh isi folder repository, lalu jalankan workflow **Build Bella Chat APK** dari tab Actions. APK debug akan tersedia sebagai artifact `Bella-Chat-APK`.

Persyaratan build: JDK 17 dan Gradle 8.9.

## Catatan verifikasi
Source Android diperbaiki. Endpoint Cloudflare belum dapat diuji dari lingkungan ini, sehingga keberhasilan model AI perlu diverifikasi melalui GitHub Actions dan uji kirim pesan di perangkat Android.
