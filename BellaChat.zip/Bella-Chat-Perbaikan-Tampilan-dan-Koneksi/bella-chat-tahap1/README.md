# Bella Chat Android — perbaikan tampilan dan koneksi

## Perbaikan source
- Tema Rose, Lavender, Peach, Mint, dan Midnight disimpan di SharedPreferences.
- Gelembung chat dibuat lebih solid agar teks terbaca di atas wallpaper.
- Riwayat percakapan diambil di main thread sebelum tugas jaringan berjalan; pesan terbaru tidak dikirim dua kali dalam riwayat.
- Respons kosong, JSON tanpa teks balasan, HTTP error, DNS, dan timeout ditangani dengan pesan diagnostik.
- Aplikasi mengirim `history` dan `message` ke `https://bella-chat-ai.asupriadi488.workers.dev/chat`.
- Izin INTERNET dan RECORD_AUDIO dideklarasikan di AndroidManifest.

## Format request
```json
{"history":[{"role":"user","content":"Halo"},{"role":"assistant","content":"Hai!"}],"message":"Apa kabar?"}
```

## Format response yang disarankan
```json
{"reply":"Bella baik, terima kasih sudah bertanya!"}
```

Aplikasi juga membaca properti teks `response`, `message`, `output`, atau `text`.

## Build
Gunakan GitHub Actions workflow `.github/workflows/android.yml` dengan JDK 17 dan Gradle 8.9. Jalankan workflow **Build Bella Chat APK**, lalu unduh artifact `Bella-Chat-APK`.

## Batas verifikasi
Perubahan source sudah diterapkan. Endpoint Cloudflare dan proses build APK belum diuji dari lingkungan ini; lakukan pengujian melalui GitHub Actions dan perangkat Android.
