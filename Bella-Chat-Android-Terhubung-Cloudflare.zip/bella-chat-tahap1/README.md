# Bella Chat — Android APK (Tahap 1)

Proyek Android native Kotlin + Jetpack Compose dengan tema pink elegan.

## Fitur tahap 1
- Tampilan chat Bella Chat.
- Mengirim dan menampilkan pesan lokal.
- Memilih gambar dari galeri dan menampilkannya di percakapan.
- Input suara Bahasa Indonesia melalui speech recognizer perangkat.
- Membacakan pesan dengan Text-to-Speech.
- Ikon aplikasi Bella.

## Batasan tahap 1
Balasan chat masih berupa placeholder lokal. AI online belum tersambung ke server/API. Analisis gambar AI, sinkronisasi akun, dan percakapan lintas perangkat belum tersedia.

## Build APK melalui GitHub Actions
1. Upload seluruh isi folder proyek ini ke root repository GitHub (jangan upload ZIP-nya saja).
2. Pastikan folder `.github/workflows` ikut ter-upload.
3. Buka tab **Actions**.
4. Pilih **Build Bella Chat APK** lalu **Run workflow**, atau lakukan commit ke branch `main`.
5. Setelah semua langkah hijau, buka hasil workflow dan unduh artifact **Bella-Chat-APK**.
6. Ekstrak artifact ZIP, lalu instal `app-debug.apk` di Android.

## Konfigurasi build
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Java/Kotlin JVM target 17
