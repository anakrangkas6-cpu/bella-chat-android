package com.bellachat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

private data class BellaTheme(
    val name: String,
    val primary: Color,
    val accent: Color,
    val pale: Color,
    val background: Color,
    val ink: Color
)

private val BellaThemes = listOf(
    BellaTheme("Rose", Color(0xFFE85D9E), Color(0xFFC83D80), Color(0xFFFCE4EF), Color(0xFFFFF7FA), Color(0xFF563346)),
    BellaTheme("Lavender", Color(0xFF9B83D5), Color(0xFF7255B5), Color(0xFFEDE7FA), Color(0xFFF9F6FF), Color(0xFF403653)),
    BellaTheme("Peach", Color(0xFFE99575), Color(0xFFC56D50), Color(0xFFFFE9DF), Color(0xFFFFF8F4), Color(0xFF573C32)),
    BellaTheme("Mint", Color(0xFF55A995), Color(0xFF347F70), Color(0xFFDDF3EC), Color(0xFFF4FBF8), Color(0xFF29483F)),
    BellaTheme("Midnight", Color(0xFF8C9EE8), Color(0xFF6476C5), Color(0xFF303957), Color(0xFF171C2D), Color(0xFFF3F4FF))
)

data class ChatMessage(
    val text: String,
    val fromBella: Boolean,
    val imageBytes: ByteArray? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val defaultTheme = BellaThemes.first()
            MaterialTheme(colorScheme = lightColorScheme(
                primary = defaultTheme.primary,
                secondary = defaultTheme.accent,
                background = defaultTheme.background,
                surface = Color.White
            )) {
                BellaChatScreen()
            }
        }
    }
}

@Composable
private fun BellaChatScreen() {
    val context = LocalContext.current
    var selectedThemeIndex by remember { mutableStateOf(0) }
    val theme = BellaThemes[selectedThemeIndex]
    var wallpaperBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var profileBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var draft by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hai! Aku Bella. Senang bisa menemanimu ngobrol. 💗", true),
            ChatMessage("Sekarang kamu bisa memilih tema, foto profil, dan latar chat. Gelembung pesan dibuat transparan.", true)
        )
    }

    fun loadBitmap(uri: android.net.Uri): android.graphics.Bitmap? {
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it)
            }
        }.getOrNull()
    }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineLanguage@ run {
                    tts?.language = Locale("id", "ID")
                }
            }
        }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            tts = null
        }
    }

    val wallpaperPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) wallpaperBitmap = loadBitmap(uri) }

    val profilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) profileBitmap = loadBitmap(uri) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) {
                messages.add(ChatMessage("Gambar yang kamu kirim:", false, bytes))
                messages.add(ChatMessage("Gambarnya sudah masuk ke percakapan. Analisis gambar AI akan ditambahkan saat koneksi AI aktif. 💗", true))
            }
        }
    }

    val speechResult = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }

    val audioPermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara dengan Bella")
            }
            runCatching { speechResult.launch(intent) }
        }
    }

    fun startVoiceInput() {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara dengan Bella")
            }
            runCatching { speechResult.launch(intent) }
        } else {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun sendToBella(text: String) {
        if (isSending) return
        isSending = true
        messages.add(ChatMessage(text, false))
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val url = URL("https://bella-chat-ai.asupriadi488.workers.dev/chat")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val payload = JSONObject().put("message", text).toString()
                connection.outputStream.use { output ->
                    output.write(payload.toByteArray(Charsets.UTF_8))
                }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = JSONObject(responseText.ifBlank { "{}" })
                if (status in 200..299) {
                    val reply = json.optString("reply").ifBlank {
                        json.optString("response").ifBlank { "Bella belum menerima jawaban dari server." }
                    }
                    Handler(Looper.getMainLooper()).post {
                        messages.add(ChatMessage(reply, true))
                        isSending = false
                    }
                } else {
                    val detail = json.optString("detail").ifBlank {
                        json.optString("error").ifBlank { "HTTP $status" }
                    }
                    Handler(Looper.getMainLooper()).post {
                        messages.add(ChatMessage("Koneksi Bella bermasalah ($status): $detail", true))
                        isSending = false
                    }
                }
            } catch (error: Exception) {
                Handler(Looper.getMainLooper()).post {
                    messages.add(ChatMessage("Tidak dapat menghubungi server Bella: ${error.message ?: "periksa koneksi internet"}", true))
                    isSending = false
                }
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    Box(modifier = Modifier.fillMaxSize().background(theme.background)) {
        if (wallpaperBitmap != null) {
            Image(
                bitmap = wallpaperBitmap!!.asImageBitmap(),
                contentDescription = "Latar belakang chat",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(theme.background.copy(alpha = 0.42f)))
        }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.82f)).padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(48.dp).background(theme.pale, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (profileBitmap != null) {
                        Image(
                            bitmap = profileBitmap!!.asImageBitmap(),
                            contentDescription = "Foto profil Bella",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(Icons.Default.Favorite, contentDescription = null, tint = theme.accent, modifier = Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Bella Chat", color = theme.ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("AI Bella • siap menemanimu", color = theme.accent, fontSize = 12.sp)
                }
                IconButton(onClick = { profilePicker.launch("image/*") }) {
                    Icon(Icons.Default.AccountCircle, contentDescription = "Ganti foto profil", tint = theme.accent)
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth()
                    .background(theme.pale.copy(alpha = 0.78f))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Tema", color = theme.ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(8.dp))
                    BellaThemes.forEachIndexed { index, item ->
                        Surface(
                            onClick = { selectedThemeIndex = index },
                            shape = RoundedCornerShape(50),
                            color = if (selectedThemeIndex == index) item.primary else Color.White.copy(alpha = 0.62f),
                            border = BorderStroke(1.dp, item.primary.copy(alpha = 0.45f)),
                            modifier = Modifier.padding(end = 5.dp)
                        ) {
                            Text(
                                item.name,
                                color = if (selectedThemeIndex == index) Color.White else item.ink,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Personalisasi", color = theme.ink, fontSize = 11.sp)
                    Spacer(Modifier.width(8.dp))
                    TextButtonCompact("Ganti latar", theme.accent) { wallpaperPicker.launch("image/*") }
                    TextButtonCompact("Hapus latar", theme.accent) { wallpaperBitmap = null }
                    TextButtonCompact("Foto profil", theme.accent) { profilePicker.launch("image/*") }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(
                        message = message,
                        bubbleColor = if (message.fromBella) Color.White.copy(alpha = 0.70f) else theme.pale.copy(alpha = 0.66f),
                        textColor = theme.ink,
                        accent = theme.accent,
                        onSpeak = { tts?.speak(message.text, TextToSpeech.QUEUE_FLUSH, null, "bella-message") }
                    )
                }
            }

            Surface(
                color = Color.White.copy(alpha = 0.84f),
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { imagePicker.launch("image/*") }) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Pilih gambar", tint = theme.accent)
                        }
                        IconButton(onClick = { startVoiceInput() }) {
                            Icon(Icons.Default.Mic, contentDescription = "Input suara", tint = theme.accent)
                        }
                        BasicTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            modifier = Modifier.weight(1f).background(theme.pale.copy(alpha = 0.65f), RoundedCornerShape(22.dp)).padding(horizontal = 15.dp, vertical = 13.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = theme.ink, fontSize = 14.sp),
                            singleLine = false,
                            maxLines = 4,
                            decorationBox = { inner ->
                                Box {
                                    if (draft.isEmpty()) Text("Tulis pesan untuk Bella...", color = Color.Gray, fontSize = 14.sp)
                                    inner()
                                }
                            }
                        )
                        Spacer(Modifier.width(6.dp))
                        Button(
                            onClick = {
                                val text = draft.trim()
                                if (text.isNotEmpty() && !isSending) {
                                    draft = ""
                                    sendToBella(text)
                                }
                            },
                            enabled = draft.isNotBlank() && !isSending,
                            shape = CircleShape,
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                            modifier = Modifier.size(46.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = theme.primary)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Kirim", tint = Color.White)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(if (isSending) "Bella sedang membalas..." else "Terhubung ke server Bella AI", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                }
            }
        }
    }
}

@Composable
private fun TextButtonCompact(label: String, tint: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.25f)),
        modifier = Modifier.padding(end = 5.dp)
    ) {
        Text(label, color = tint, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}

@Composable
private fun MessageBubble(
    message: ChatMessage,
    bubbleColor: Color,
    textColor: Color,
    accent: Color,
    onSpeak: () -> Unit
) {
    val alignment = if (message.fromBella) Alignment.Start else Alignment.End
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 20.dp, topEnd = 20.dp,
                bottomStart = if (message.fromBella) 5.dp else 20.dp,
                bottomEnd = if (message.fromBella) 20.dp else 5.dp
            ),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth(0.86f)
        ) {
            Column(Modifier.padding(12.dp)) {
                if (message.imageBytes != null) {
                    val bitmap = remember(message.imageBytes) {
                        BitmapFactory.decodeByteArray(message.imageBytes, 0, message.imageBytes.size)
                    }
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Gambar yang dipilih",
                            modifier = Modifier.fillMaxWidth().height(190.dp),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                }
                Text(message.text, color = textColor, fontSize = 14.sp)
                if (message.fromBella) {
                    IconButton(onClick = onSpeak, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Bacakan pesan", tint = accent, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
