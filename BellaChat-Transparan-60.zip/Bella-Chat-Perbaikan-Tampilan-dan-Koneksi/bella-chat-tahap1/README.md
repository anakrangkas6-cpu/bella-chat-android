# Bella Chat Android

Source Android Kotlin + Jetpack Compose.

## Perbaikan tampilan dan koneksi
- Pengaturan tema Rose, Lavender, Peach, Mint, dan Midnight berada di halaman Pengaturan (ikon roda gigi), bukan di atas percakapan.
- Pesan pengguna tampil di kanan dan balasan Bella di kiri dalam gelembung terpisah.
- Wallpaper tampil jelas dengan lapisan warna sangat tipis.
- Daftar percakapan otomatis bergulir ke pesan terbaru.
- Pesan teks dikirim ke Cloudflare Worker melalui `POST https://bella-chat-ai.asupriadi488.workers.dev/chat` dengan JSON `{ "message": "..." }`.
- Respons membaca properti `reply` atau `response`.

## Build APK melalui GitHub Actions
Workflow ada di `.github/workflows/android.yml`. Upload seluruh isi folder repository, lalu jalankan workflow **Build Bella Chat APK** dari tab Actions. APK debug akan tersedia sebagai artifact `Bella-Chat-APK`.

Persyaratan build: JDK 17 dan Gradle 8.9.
