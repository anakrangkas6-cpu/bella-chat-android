# Bella Chat — Perbaikan tampilan dan koneksi

## Perubahan pada MainActivity.kt
- Gelembung pesan Bella dan pengguna memakai opacity 40% (transparansi 60%).
- Overlay warna di atas wallpaper dihapus agar wallpaper percakapan terlihat lebih jelas.
- Border dan bayangan gelembung dibuat halus agar teks tetap terbaca.
- Tema pilihan disimpan ke SharedPreferences dan dipulihkan saat aplikasi dibuka kembali.
- Riwayat percakapan di-snapshot di main thread sebelum permintaan jaringan dijalankan.
- Pesan terbaru dikirim sekali sebagai `message`, sedangkan riwayat sebelumnya dikirim sebagai `history`.
- Penanganan respons kosong dan format JSON balasan diperjelas.

## Catatan
Perubahan Android ini belum menguji endpoint Cloudflare secara langsung. Worker juga harus menerima `body.history` dan memasukkan riwayat tersebut ke array `messages` model, diikuti pesan terbaru satu kali.
