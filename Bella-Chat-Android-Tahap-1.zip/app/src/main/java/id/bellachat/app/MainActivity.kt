package id.bellachat.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Rose = Color(0xFFC96F89)
private val PalePink = Color(0xFFFFF1F4)
private val Ink = Color(0xFF382B31)
private const val PREFS = "bella_chat_appearance"
private const val PROFILE_URI = "profile_uri"
private const val WALLPAPER_URI = "wallpaper_uri"

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("id", "ID")
        }
        setContent { BellaChatScreen(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bella-reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private fun loadBitmap(context: Context, uri: Uri) = runCatching {
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
}.getOrNull()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BellaChatScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(ChatMessage("Hai! Aku Bella 🌷 Senang bisa menemanimu. Mau ngobrol apa hari ini?", false)))
    }
    var attachmentName by remember { mutableStateOf<String?>(null) }
    var showAppearance by remember { mutableStateOf(false) }
    var profileUri by remember { mutableStateOf(prefs.getString(PROFILE_URI, null)) }
    var wallpaperUri by remember { mutableStateOf(prefs.getString(WALLPAPER_URI, null)) }

    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            profileUri = uri.toString()
            prefs.edit().putString(PROFILE_URI, profileUri).apply()
        }
    }
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            wallpaperUri = uri.toString()
            prefs.edit().putString(WALLPAPER_URI, wallpaperUri).apply()
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        attachmentName = uri?.lastPathSegment?.substringAfterLast('/')
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeechInput(context) { recognized -> input = recognized }
    }

    val profileBitmap = remember(profileUri) { profileUri?.let { loadBitmap(context, Uri.parse(it)) } }
    val wallpaperBitmap = remember(wallpaperUri) { wallpaperUri?.let { loadBitmap(context, Uri.parse(it)) } }

    fun sendMessage() {
        val text = input.trim()
        if (text.isNotEmpty() || attachmentName != null) {
            val content = buildString {
                if (text.isNotEmpty()) append(text)
                if (attachmentName != null) {
                    if (isNotEmpty()) append("\n")
                    append("📷 Gambar dipilih: $attachmentName")
                }
            }
            messages = messages + ChatMessage(content, true)
            input = ""
            attachmentName = null
            messages = messages + ChatMessage(
                "Pesanmu sudah masuk. Koneksi AI Bella ke Cloudflare akan diaktifkan pada tahap berikutnya. 💗",
                false
            )
        }
    }

    Scaffold(
        containerColor = PalePink,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (profileBitmap != null) {
                            Image(
                                bitmap = profileBitmap.asImageBitmap(),
                                contentDescription = "Foto profil Bella",
                                modifier = Modifier.size(48.dp).clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Image(
                                painter = painterResource(R.drawable.bella_profile),
                                contentDescription = "Foto profil Bella",
                                modifier = Modifier.size(48.dp).clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Bella", color = Ink, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                            Text("Teman AI kamu", color = Rose, fontSize = 12.sp)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showAppearance = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Pengaturan tampilan", tint = Rose)
                    }
                    Spacer(Modifier.width(4.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White, titleContentColor = Ink)
            )
        },
        bottomBar = {
            Column(Modifier.background(Color.White).padding(horizontal = 12.dp, vertical = 10.dp)) {
                if (attachmentName != null) Text("Gambar terpilih: $attachmentName", color = Rose, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    IconButton(onClick = { imagePicker.launch("image/*") }) {
                        Icon(Icons.Default.AddPhotoAlternate, "Pilih gambar", tint = Rose)
                    }
                    IconButton(onClick = { permission.launch(Manifest.permission.RECORD_AUDIO) }) {
                        Icon(Icons.Default.Mic, "Input suara", tint = Rose)
                    }
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Tulis pesan untuk Bella…", fontSize = 13.sp) },
                        shape = RoundedCornerShape(22.dp),
                        maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Rose, unfocusedBorderColor = Color(0xFFEBD7DE))
                    )
                    IconButton(onClick = { sendMessage() }, modifier = Modifier.background(Rose, CircleShape)) {
                        Icon(Icons.Default.Send, "Kirim", tint = Color.White)
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).background(PalePink)) {
            if (wallpaperBitmap != null) {
                Image(
                    bitmap = wallpaperBitmap.asImageBitmap(),
                    contentDescription = "Wallpaper chat",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.38f
                )
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("HARI INI", modifier = Modifier.fillMaxWidth(), color = Color(0xFF9D7D88), fontSize = 10.sp)
                }
                items(messages) { message ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (message.fromUser) Color(0xFFF3D5DF) else Color.White,
                            shape = RoundedCornerShape(
                                topStart = 18.dp, topEnd = 18.dp,
                                bottomStart = if (message.fromUser) 18.dp else 5.dp,
                                bottomEnd = if (message.fromUser) 5.dp else 18.dp
                            ),
                            shadowElevation = 1.dp,
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(message.text, color = Ink, fontSize = 14.sp, modifier = Modifier.weight(1f, fill = false))
                                if (!message.fromUser) {
                                    Spacer(Modifier.width(5.dp))
                                    IconButton(onClick = { onSpeak(message.text) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Default.VolumeUp, "Bacakan pesan", tint = Rose, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAppearance) {
        AlertDialog(
            onDismissRequest = { showAppearance = false },
            title = { Text("Tampilan Bella Chat", color = Ink) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Atur foto profil dan latar belakang chat.", color = Ink)
                    OutlinedButton(onClick = { profilePicker.launch(arrayOf("image/*")) }) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Rose)
                        Spacer(Modifier.width(8.dp))
                        Text("Ganti foto profil Bella")
                    }
                    OutlinedButton(onClick = { wallpaperPicker.launch(arrayOf("image/*")) }) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Rose)
                        Spacer(Modifier.width(8.dp))
                        Text("Ganti latar belakang")
                    }
                    TextButton(onClick = {
                        wallpaperUri = null
                        prefs.edit().remove(WALLPAPER_URI).apply()
                    }) { Text("Reset latar belakang") }
                }
            },
            confirmButton = { TextButton(onClick = { showAppearance = false }) { Text("Selesai") } },
            containerColor = Color.White
        )
    }
}

private fun startSpeechInput(context: Context, onResult: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) return
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicara dengan Bella")
    }
    try { context.startActivity(intent) } catch (_: Exception) { }
}
