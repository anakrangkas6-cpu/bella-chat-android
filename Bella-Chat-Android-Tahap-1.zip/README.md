# Bella Chat — Android starter (Tahap 1)

Aplikasi Android native menggunakan Kotlin + Jetpack Compose dengan tema pink elegan.

## Yang sudah dibuat
- Kerangka aplikasi Android dan layar chat.
- UI percakapan dengan gelembung pesan.
- Input teks dan tombol kirim.
- Pemilih gambar dari galeri (UI memilih gambar; upload ke AI belum diaktifkan).
- Input suara melalui Android Speech Recognizer (bergantung layanan pengenalan suara perangkat).
- Text-to-Speech untuk membacakan balasan Bella.
- Konfigurasi permission internet dan mikrofon.

## Belum diaktifkan
- Respons AI sungguhan.
- Upload gambar ke backend.
- Penyimpanan riwayat permanen / sinkronisasi akun.
- Build APK dan signing release.

## Build
Buka folder ini dengan Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
Tunggu Gradle Sync, lalu pilih **Build > Build APK(s)**.

## Tahap berikutnya
Buat Cloudflare Worker dengan endpoint `/api/chat`, simpan API key sebagai secret di Cloudflare,
lalu hubungkan aplikasi dengan HTTPS. Jangan menaruh API key di aplikasi Android.
