# Bella Chat Android

Project Android Bella Chat (Kotlin + Jetpack Compose).

## Pembaruan tampilan
- Foto profil Bella menggunakan foto referensi yang disertakan di `app/src/main/res/drawable-nodpi/bella_profile.png`.
- Tombol pengaturan di kanan atas membuka pilihan untuk mengganti foto profil dari galeri.
- Pengguna dapat memilih wallpaper chat dari galeri atau meresetnya ke warna pink.
- Pilihan foto profil dan wallpaper disimpan di SharedPreferences agar tetap digunakan saat aplikasi dibuka kembali.

## Build
Gunakan JDK 17 dan Gradle 8.9:

```bash
gradle assembleDebug
```

APK akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: balasan AI masih berupa placeholder lokal. Koneksi ke Cloudflare Worker belum diaktifkan pada versi ini.
