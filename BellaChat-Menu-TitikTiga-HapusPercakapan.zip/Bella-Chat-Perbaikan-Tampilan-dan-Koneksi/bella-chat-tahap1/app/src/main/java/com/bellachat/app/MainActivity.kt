package com.bellachat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

private const val BELLA_API_URL = "https://bella-chat-ai.asupriadi488.workers.dev/chat"

private data class BellaTheme(val name: String, val primary: Color, val accent: Color, val pale: Color, val background: Color, val ink: Color)
private val BellaThemes = listOf(
    BellaTheme("Rose", Color(0xFFE85D9E), Color(0xFFC83D80), Color(0xFFFCE4EF), Color(0xFFFFF7FA), Color(0xFF563346)),
    BellaTheme("Lavender", Color(0xFF9B83D5), Color(0xFF7255B5), Color(0xFFEDE7FA), Color(0xFFF9F6FF), Color(0xFF403653)),
    BellaTheme("Peach", Color(0xFFE99575), Color(0xFFC56D50), Color(0xFFFFE9DF), Color(0xFFFFF8F4), Color(0xFF573C32)),
    BellaTheme("Mint", Color(0xFF55A995), Color(0xFF347F70), Color(0xFFDDF3EC), Color(0xFFF4FBF8), Color(0xFF29483F)),
    BellaTheme("Midnight", Color(0xFF8C9EE8), Color(0xFF6476C5), Color(0xFF303957), Color(0xFF171C2D), Color(0xFFF3F4FF))
)

private data class ChatMessage(val id: Long, val text: String, val fromBella: Boolean, val imageBytes: ByteArray? = null)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BellaChatScreen() }
    }
}

@Composable
private fun BellaChatScreen() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("bella_chat_settings", android.content.Context.MODE_PRIVATE) }
    var selectedThemeIndex by remember {
        mutableIntStateOf(preferences.getInt("theme_index", 0).coerceIn(0, BellaThemes.lastIndex))
    }
    val theme = BellaThemes[selectedThemeIndex]
    var wallpaperBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var profileBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var draft by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }
    var showClearConfirmation by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val listState = rememberLazyListState()
    val messages = remember { mutableStateListOf(
        ChatMessage(1, "Hai! Aku Bella. Senang bisa menemanimu ngobrol. 💗", true)
    ) }

    fun loadBitmap(uri: android.net.Uri): android.graphics.Bitmap? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    }.getOrNull()

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) engineLanguage@ run { tts?.language = Locale("id", "ID") } }
        tts = engine
        onDispose { engine.stop(); engine.shutdown(); tts = null; executor.shutdown() }
    }

    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) wallpaperBitmap = loadBitmap(uri) }
    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) profileBitmap = loadBitmap(uri) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) messages.add(ChatMessage(System.nanoTime(), "Foto terkirim. Untuk saat ini foto belum dianalisis oleh AI.", false, bytes))
        }
    }
    val speechResult = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = spoken
    }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) runCatching { speechResult.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara dengan Bella")
        }) }
    }

    fun startVoiceInput() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) runCatching { speechResult.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara dengan Bella")
        }) } else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun sendMessage() {
        val text = draft.trim()
        if (text.isEmpty() || sending) return

        // Ambil riwayat di main thread; jangan membaca SnapshotStateList dari executor.
        val historySnapshot = messages
            .filter { it.imageBytes == null }
            .takeLast(10)
            .map { message ->
                JSONObject()
                    .put("role", if (message.fromBella) "assistant" else "user")
                    .put("content", message.text)
            }

        messages.add(ChatMessage(System.nanoTime(), text, false))
        draft = ""
        sending = true

        executor.execute {
            val resultText = try {
                val historyArray = org.json.JSONArray()
                historySnapshot.forEach { historyArray.put(it) }
                val payload = JSONObject()
                    .put("history", historyArray)
                    .put("message", text)

                val connection = (URL(BELLA_API_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                try {
                    connection.outputStream.use {
                        it.write(payload.toString().toByteArray(Charsets.UTF_8))
                    }
                    val code = connection.responseCode
                    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    val json = runCatching { JSONObject(body) }.getOrNull()

                    if (code !in 200..299) {
                        val error = json?.optString("error")?.takeIf { it.isNotBlank() } ?: body.take(500)
                        val detail = json?.optString("detail")?.takeIf { it.isNotBlank() }
                        "Server Bella mengembalikan kesalahan ($code): $error${detail?.let { "\n$it" } ?: ""}"
                    } else {
                        val reply = json?.let {
                            listOf("reply", "response", "message", "output", "text")
                                .firstNotNullOfOrNull { key ->
                                    it.optString(key).takeIf { value -> value.isNotBlank() && value != "null" }
                                }
                        }
                        reply ?: if (body.isBlank()) "Server Bella mengirim respons kosong." else
                            "Server merespons, tetapi format balasannya tidak dikenali."
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: java.net.SocketTimeoutException) {
                "Koneksi ke Bella timeout. Coba lagi beberapa saat."
            } catch (e: Exception) {
                "Tidak dapat menghubungi server Bella: ${e.localizedMessage ?: "Periksa koneksi internet."}"
            }

            mainHandler.post {
                messages.add(ChatMessage(System.nanoTime(), resultText, true))
                sending = false
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            delay(80)
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    if (showClearConfirmation) {
        AlertDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text("Hapus semua percakapan?") },
            text = { Text("Semua pesan di ruang chat ini akan dihapus. Tindakan ini tidak dapat dibatalkan.") },
            confirmButton = {
                TextButton(onClick = {
                    messages.clear()
                    messages.add(ChatMessage(System.nanoTime(), "Hai! Aku Bella. Senang bisa menemanimu ngobrol. 💗", true))
                    showClearConfirmation = false
                    settingsOpen = false
                }) {
                    Text("Hapus", color = Color(0xFFB3261E))
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmation = false }) {
                    Text("Batal")
                }
            }
        )
    }

    Box(Modifier.fillMaxSize().background(theme.background)) {
        if (wallpaperBitmap != null) {
            Image(bitmap = wallpaperBitmap!!.asImageBitmap(), contentDescription = "Wallpaper percakapan", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().background(theme.background.copy(alpha = 0.94f)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(48.dp).background(theme.pale, CircleShape), contentAlignment = Alignment.Center) {
                    if (profileBitmap != null) Image(profileBitmap!!.asImageBitmap(), "Foto profil Bella", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.Favorite, null, tint = theme.accent, modifier = Modifier.size(25.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("Bella Chat", color = theme.ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(if (sending) "Bella sedang membalas…" else "Siap menemanimu", color = theme.accent, fontSize = 12.sp)
                }
                IconButton(onClick = { settingsOpen = !settingsOpen }) {
                    Icon(if (settingsOpen) Icons.Default.ArrowBack else Icons.Default.MoreVert, contentDescription = if (settingsOpen) "Kembali" else "Menu", tint = theme.accent)
                }
            }

            if (settingsOpen) {
                Column(Modifier.fillMaxSize().background(theme.background).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Pengaturan", color = theme.ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Tema aplikasi", color = theme.ink, fontWeight = FontWeight.SemiBold)
                    BellaThemes.forEachIndexed { index, item ->
                        Surface(onClick = { selectedThemeIndex = index; preferences.edit().putInt("theme_index", index).apply() }, shape = RoundedCornerShape(16.dp), color = if (selectedThemeIndex == index) item.pale else Color.White.copy(alpha = 0.88f), border = BorderStroke(if (selectedThemeIndex == index) 2.dp else 1.dp, item.primary.copy(alpha = 0.65f)), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(24.dp).background(item.primary, CircleShape))
                                Spacer(Modifier.width(12.dp))
                                Text(item.name, color = item.ink, modifier = Modifier.weight(1f))
                                if (selectedThemeIndex == index) Text("Aktif ✓", color = item.accent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Divider(color = theme.accent.copy(alpha = 0.25f))
                    Text("Personalisasi", color = theme.ink, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(
                        onClick = { showClearConfirmation = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E))
                    ) {
                        Text("Hapus semua percakapan")
                    }
                    OutlinedButton(onClick = { wallpaperPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Pilih wallpaper dari galeri") }
                    OutlinedButton(onClick = { wallpaperBitmap = null }, modifier = Modifier.fillMaxWidth()) { Text("Hapus wallpaper") }
                    OutlinedButton(onClick = { profilePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text("Ganti foto profil Bella") }
                    Text("Alamat server AI: bella-chat-ai.asupriadi488.workers.dev/chat", color = theme.ink.copy(alpha = 0.65f), fontSize = 11.sp)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        MessageBubble(message, if (message.fromBella) Color.White.copy(alpha = 0.40f) else theme.pale.copy(alpha = 0.40f), theme.ink, theme.accent) {
                            tts?.speak(message.text, TextToSpeech.QUEUE_FLUSH, null, "bella-${message.id}")
                        }
                    }
                    if (sending) item { Text("Bella sedang mengetik…", color = theme.accent, fontSize = 12.sp, modifier = Modifier.padding(8.dp)) }
                }
                Surface(color = theme.background.copy(alpha = 0.96f), shadowElevation = 8.dp, shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { imagePicker.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, "Pilih foto", tint = theme.accent) }
                        IconButton(onClick = { startVoiceInput() }) { Icon(Icons.Default.Mic, "Input suara", tint = theme.accent) }
                        BasicTextField(
                            value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f).background(theme.pale, RoundedCornerShape(24.dp)).padding(horizontal = 15.dp, vertical = 13.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = theme.ink, fontSize = 14.sp), maxLines = 4,
                            decorationBox = { inner -> Box { if (draft.isEmpty()) Text("Tulis pesan untuk Bella…", color = theme.ink.copy(alpha = 0.5f), fontSize = 14.sp); inner() } }
                        )
                        Spacer(Modifier.width(5.dp))
                        Button(onClick = { sendMessage() }, enabled = draft.isNotBlank() && !sending, shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(46.dp), colors = ButtonDefaults.buttonColors(containerColor = theme.primary)) {
                            Icon(Icons.Default.Send, "Kirim", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, bubbleColor: Color, textColor: Color, accent: Color, onSpeak: () -> Unit) {
    val alignment = if (message.fromBella) Alignment.Start else Alignment.End
    Column(Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(topStart = 19.dp, topEnd = 19.dp, bottomStart = if (message.fromBella) 5.dp else 19.dp, bottomEnd = if (message.fromBella) 19.dp else 5.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.72f)), shadowElevation = 3.dp, modifier = Modifier.fillMaxWidth(0.84f)
        ) {
            Column(Modifier.padding(12.dp)) {
                if (message.imageBytes != null) {
                    val bitmap = remember(message.imageBytes) { BitmapFactory.decodeByteArray(message.imageBytes, 0, message.imageBytes.size) }
                    if (bitmap != null) Image(bitmap.asImageBitmap(), "Foto dalam chat", Modifier.fillMaxWidth().height(190.dp), contentScale = ContentScale.Crop)
                    Spacer(Modifier.height(6.dp))
                }
                Text(message.text, color = textColor, fontSize = 14.sp)
                if (message.fromBella) IconButton(onClick = onSpeak, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.VolumeUp, "Bacakan pesan", tint = accent, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}
